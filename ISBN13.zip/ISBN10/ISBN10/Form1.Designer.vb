﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.isbn9TextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.isbn10Label = New System.Windows.Forms.Label()
        Me.displayButton = New System.Windows.Forms.Button()
        Me.resetButton = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblSum = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblCheckSum = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(250, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter the first 12 digits of an ISBN-13: "
        '
        'isbn9TextBox
        '
        Me.isbn9TextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.isbn9TextBox.Location = New System.Drawing.Point(285, 39)
        Me.isbn9TextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.isbn9TextBox.Name = "isbn9TextBox"
        Me.isbn9TextBox.Size = New System.Drawing.Size(169, 30)
        Me.isbn9TextBox.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 118)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(163, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "The ISBN-10 number is: "
        '
        'isbn10Label
        '
        Me.isbn10Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.isbn10Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.isbn10Label.Location = New System.Drawing.Point(317, 112)
        Me.isbn10Label.Name = "isbn10Label"
        Me.isbn10Label.Size = New System.Drawing.Size(174, 30)
        Me.isbn10Label.TabIndex = 3
        '
        'displayButton
        '
        Me.displayButton.Location = New System.Drawing.Point(41, 271)
        Me.displayButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.displayButton.Name = "displayButton"
        Me.displayButton.Size = New System.Drawing.Size(112, 33)
        Me.displayButton.TabIndex = 4
        Me.displayButton.Text = "Display"
        Me.displayButton.UseVisualStyleBackColor = True
        '
        'resetButton
        '
        Me.resetButton.Location = New System.Drawing.Point(181, 271)
        Me.resetButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.resetButton.Name = "resetButton"
        Me.resetButton.Size = New System.Drawing.Size(119, 33)
        Me.resetButton.TabIndex = 5
        Me.resetButton.Text = "Reset"
        Me.resetButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(19, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(404, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Sum=d1+3d2+d3+3d4+d5+3d6+d7+3d8+d9+3d10+d11+3d12=" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblSum
        '
        Me.lblSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSum.Location = New System.Drawing.Point(421, 16)
        Me.lblSum.Name = "lblSum"
        Me.lblSum.Size = New System.Drawing.Size(70, 30)
        Me.lblSum.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 63)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(124, 17)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "10-Sum Mod 10 = " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblCheckSum
        '
        Me.lblCheckSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCheckSum.Location = New System.Drawing.Point(421, 62)
        Me.lblCheckSum.Name = "lblCheckSum"
        Me.lblCheckSum.Size = New System.Drawing.Size(70, 28)
        Me.lblCheckSum.TabIndex = 9
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblCheckSum)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblSum)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.isbn10Label)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(20, 86)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(503, 167)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(556, 353)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.resetButton)
        Me.Controls.Add(Me.displayButton)
        Me.Controls.Add(Me.isbn9TextBox)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.Text = "Check ISBN10"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents isbn9TextBox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents isbn10Label As Label
    Friend WithEvents displayButton As Button
    Friend WithEvents resetButton As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents lblSum As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblCheckSum As Label
    Friend WithEvents GroupBox1 As GroupBox
End Class
